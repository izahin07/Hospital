#include<stdio.h>
#include<string.h>
#include<conio.h>
int a,x,y,z;
char username[10];
char password[10];
char ID[10];
void menu();


struct patient
{
    char name[15];
    char address[15];
    int id;
    int age;
    char gender[6];
    char nationality[10];
    char disorders[100];
    char appointeddoc[20];


};
void new_patient(int s)
{
    if(s==4)
    {
        struct patient p;
        printf("Entry New Patient: \n\n");
        printf("Patient Name: \n");
        scanf("%s",&p.name);
        printf("Patient Address: \n");
        scanf("%s",&p.address);
        printf("Patient ID: \n");
        scanf("%d",&p.id);
        printf("Patient Age: \n");
        scanf("%d",&p.age);
        printf("Gender: \n");
        scanf("%s",&p.gender);
        printf("NATIONALITY: \n");
        scanf("%s",&p.nationality);
        printf("Disorders: \n");
        scanf("%s",&p.disorders);
        printf("Appointed Doctor: \n");
        scanf("%s",&p.appointeddoc);
        menu();
        return;
    }

}




void patient()
{
    printf("Patient ID: 10047\n");
    printf("Patient Name: Sheikh Abujar\n");
    printf("Patient Age: 26\n");
    printf("Patient Address: Dhaka\n");
    printf("Patient NID: ******\n");
    printf("Patient Mobile No.: *****\n\n");
}
void doctor_info()
{
    printf("\n\tDoctor Information: \n");
    printf("\n\tDoctor ID: 9710\n");
    printf("\tDoctor Name: Zahin Hossain\n");
    printf("\tDoctor Initial: MBBS, FRCS, LONDON\n");
    printf("\tDoctor Department : Cardiology\n");
    printf("\tDHAKA MEDICAL COLLEGE, DHAKA\n");
    printf("\tDoctor Mobile No.: *****\n");
    printf("\tVisiting Hour: **:**\n");
    printf("\tROOM NO.:****\n");
    printf("\tEmail: *****@gmail.com\n\n");
}
void stuff_info()
{
    printf("\n\tStuff NO.1\n");
    printf("\tStuff Name: Adil Ansary\n");
    printf("\tStuff ID: 10104\n");
    printf("\tShift: Day\n");
    printf("\tSchedule: 08:00AM - 01:00PM\n\n");
}


void stuff1_info()
{
    printf("\n\tStuff NO.2\n");
    printf("\tStuff Name: Mahdi Hasan\n");
    printf("\tStuff ID: 100041\n");
    printf("\tShift: Night\n");
    printf("\tSchedule: 01:00AM - 08:00AM\n\n");

}


void test_report()
{
    printf("Patient ID: 10047\n");
    printf("Patient Name: Sheikh Abujar\n");
    printf("Patient Age: 26\n");
    printf("Patient Type: New Patient\n");
    printf("Test Type:\n\t1.Blood Test = (-)ve\n\t2.Urine Test = (-)ve\n\t3.Sugar Test = (+)ve\n\n");

}

void patient(int p)
{
    if(p==3)
        {

            printf("please Enter your username: \n");
            scanf("%s",&username);
            printf("Please Enter your Password: ");
            scanf("%s",&password);
            if(strcmp(username, "ghi") == 0)
            {
                if(strcmp(password, "789") == 0)
                {
                    printf("1.patient information: \n");
                    printf("2.Test Report: \n");
                    printf("3.Back \n");
                    printf("Enter Your choice: \n");

                    scanf("%d",&x);
                    if(x==1)
                    {

                            printf("Enter patient ID: \n");
                            scanf("%s",&ID);
                            if(strcmp(ID,"10047")==0)
                            {
                                patient();
                                menu();

                            }

                    }
                    else if(x==2)
                    {

                            printf("Enter patient ID: \n");
                            scanf("%s",&ID);
                            if(strcmp(ID,"10047")==0)
                            {
                                test_report();
                                menu();
                            }

                    }
                    else if(x==3)
                    {
                        menu();
                    }


                }

                else
                {
                    printf("Password is incorrect\nTry again!!!\n");
                    menu();
                }
            }
            else
            {
                printf("Username is incorrect\nTry again!!\n");
                menu();

            }

        }
}

void doctor(int q)
{
    if(q==1)
        {

            printf("please Enter your username: \n");
            scanf("%s",&username);
            printf("Please Enter your Password: ");
            scanf("%s",&password);
            if(strcmp(username, "abc") == 0)
            {
                if(strcmp(password, "123") == 0)
                {
                    printf("1.Doctor information: \n");
                    printf("2.Back \n");
                    printf("Enter Your Choice: \n");

                    scanf("%d",&y);
                    if(y==1)
                    {

                            printf("Enter Doctor ID: \n");
                            scanf("%s",&ID);
                            if(strcmp(ID,"9710")==0)
                            {
                                doctor_info();
                                menu();
                            }

                    }
                    else if(y==2)
                    {
                        menu();
                    }



                }

                else
                {
                    printf("Password is incorrect\nTry again!!!\n");
                    menu();
                }
            }
            else
            {
                printf("Username is incorrect\nTry again!!\n");
                menu();

            }

        }

}

void stuff(int r)
{
    if(r==2)
        {

            printf("please Enter your username: \n");
            scanf("%s",&username);
            printf("Please Enter your Password: ");
            scanf("%s",&password);
            if(strcmp(username, "def") == 0)
            {
                if(strcmp(password, "456") == 0)
                {
                    printf("1.Stuff information: \n");

                    printf("2.Back \n");
                    printf("Enter your choice: \n");

                    scanf("%d",&z);
                    if(z==1)
                    {

                            printf("Enter Stuff ID: \n");
                            scanf("%s",&ID);
                            if(strcmp(ID,"10104")==0)
                            {
                                stuff_info();
                            }

                            printf("Enter Another Stuff ID: \n");
                            scanf("%s",&ID);
                            if(strcmp(ID,"10041")==0)
                            {
                                stuff1_info();
                                menu();
                            }

                    }
                    else if(z==2)
                    {
                        menu();
                    }


                }

                else
                {
                    printf("Password is incorrect\nTry again!!!\n");
                    menu();
                }
            }
            else
            {
                printf("Username is incorrect\nTry again!!\n");
                menu();

            }

        }
}


int main()
{



    int a;
    char username[10];
    char password[10];
    char ID[10];



        printf("\t\t\t\t::Welcome To E-Hospital Management::\n\n");

        printf("1.Login As Doctor: \n");
        printf("2.Login As Stuff: \n");
        printf("3.Login As patient \n");
        printf("4.New Patient Entry: \n");
        printf("\nEnter any number: \n");
            while((scanf("%d",&a))!=EOF)
{

        patient(a);
        doctor(a);
        stuff(a);
        new_patient(a);



    return 0;
}
}
void menu()
{
        printf("1.Login As Doctor: \n");
        printf("2.Login As Stuff: \n");
        printf("3.Login As patient \n");
        printf("4.New Patient Entry: \n");
        printf("Enter any number: \n");
        scanf("%d",&a);

        patient(a);
        doctor(a);
        stuff(a);
        new_patient(a);

}


